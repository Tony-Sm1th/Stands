/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
//#include "usb_device.h"
//#include "usbd_cdc_if.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

DAC_HandleTypeDef hdac;

SPI_HandleTypeDef hspi2;

UART_HandleTypeDef huart5;

/* USER CODE BEGIN PV */
const float adc_to_v = 0.000805860805861; //Кон�?танта дл�? перевода значений �?ЦП в напр�?жение

bool tx_flag = 0; //Флаг дл�? отправки. 0 - не надо ничего отправл�?ть. 1 - надо.
bool heat_flag = 1; //Отвечает за режим. 1 - Штатный. 0 - Прожиг.
bool on_flag = 0; //Флаг разрешени�? на включение. 0 - нельз�?. 1 - можно.
bool on_man_flag = 0; //Флаг включения

uint8_t rx_buff; //Буффер приёма
uint8_t tx_buff[100]; //Буфер прин�?тых данных
uint8_t rx_count; //Счётчик прин�?тых �?имволов
uint8_t tx_size; //Сколько �?имволов было прин�?то
uint8_t msg[100]; //Буфер дл�? отправки �?ообщений
uint16_t adc_value; //Значение �?ЦП
uint32_t millisec = 0; //Дл�? �?чётчика HAL_GetTick()
unsigned long int heat_value = 0; //У�?тановленное на Ц�?П значение.
unsigned int heat_for_adc = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI2_Init(void);
static void MX_UART5_Init(void);
static void MX_DAC_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_SPI2_Init();
  MX_UART5_Init();
  MX_DAC_Init();
  /* USER CODE BEGIN 2 */
  HAL_GPIO_WritePin(ON_ALLOW_GPIO_Port, ON_ALLOW_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(ON_MAN_LED_GPIO_Port, ON_MAN_LED_Pin, GPIO_PIN_SET);
  HAL_Delay(500);
  HAL_GPIO_WritePin(ON_ALLOW_GPIO_Port, ON_ALLOW_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ON_MAN_LED_GPIO_Port, ON_MAN_LED_Pin, GPIO_PIN_RESET);

  HAL_DAC_Start(&hdac, DAC_CHANNEL_2);
  HAL_UART_Receive_IT(&huart5, &rx_buff, 1);
  HAL_GPIO_WritePin(HEAT_GPIO_Port, HEAT_Pin, GPIO_PIN_SET);
  HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, 0);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  /*HAL_GPIO_WritePin(UART_RS485_2_GPIO_Port, UART_RS485_2_Pin, GPIO_PIN_SET);
	  if(HAL_UART_Transmit(&huart5, (uint8_t*) "U", 1, HAL_MAX_DELAY) != HAL_OK){
		  HAL_GPIO_WritePin(ON_ALLOW_GPIO_Port, ON_ALLOW_Pin, GPIO_PIN_SET);
	  }
	  HAL_Delay(10);*/
	  //Проверка напр�?жени�? �? помощью �?ЦП.
	  if(HAL_GetTick() - millisec >= 1000 && HAL_GPIO_ReadPin(TX_SIGNAL_GPIO_Port, TX_SIGNAL_Pin) == 0) {
		  millisec = HAL_GetTick();

		  HAL_ADC_Start(&hadc1);
		  HAL_ADC_PollForConversion(&hadc1, 100);
		  adc_value = HAL_ADC_GetValue(&hadc1);
		  HAL_ADC_Stop(&hadc1);

		  HAL_GPIO_WritePin(UART_RS485_2_GPIO_Port, UART_RS485_2_Pin, GPIO_PIN_SET);
		  //printf("\nADC value: %.3f%s", adc_value * adc_to_v, "\r\n");

		  if(abs(adc_value - (heat_for_adc * 4095 / 1650)) < 125 && heat_flag == 0) { //Е�?ли режим прожига
			  on_flag = 1;
			  HAL_GPIO_WritePin(ON_ALLOW_GPIO_Port, ON_ALLOW_Pin, GPIO_PIN_SET);

			  //HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\n.You can on Mantigora."), HAL_MAX_DELAY);
			  if(on_man_flag) {
				  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nMantigora state ON."), HAL_MAX_DELAY);
				  //printf("Mantigora state ON.\r\n");
			  } else {
				  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nYou can on Mantigora."), HAL_MAX_DELAY);
			  	  //printf("You can on Mantigora.\r\n");
			  }
		  } else if(abs(adc_value - 1241) < 125 && heat_flag == 1) { //Е�?ли режим штатный
			  on_flag = 1;
			  HAL_GPIO_WritePin(ON_ALLOW_GPIO_Port, ON_ALLOW_Pin, GPIO_PIN_SET);

			  //HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\n.You can on Mantigora."), HAL_MAX_DELAY);
			  if(on_man_flag) {
				  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nMantigora state ON."), HAL_MAX_DELAY);
				  //printf("Mantigora state ON.\r\n");
			  } else {
				  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nYou can on Mantigora."), HAL_MAX_DELAY);
			  	  //printf("You can on Mantigora.\r\n");
			  }
		  } else { //Е�?ли напр�?жение на �?ЦП не �?оответ�?твует напр�?жению на двух режимах
			  if(heat_flag == 1) {
				  HAL_GPIO_WritePin(ON_MAN_GPIO_Port, ON_MAN_Pin, GPIO_PIN_RESET);
				  HAL_GPIO_WritePin(ON_MAN_LED_GPIO_Port, ON_MAN_LED_Pin, GPIO_PIN_RESET);
				  HAL_GPIO_WritePin(ON_ALLOW_GPIO_Port, ON_ALLOW_Pin, GPIO_PIN_RESET);
				  on_man_flag = 0;
				  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nMantigora voltage check error."), HAL_MAX_DELAY);
				  //printf("Mantigora voltage check error.\r\n");
				  on_flag = 0;
			  } else {
				  if(on_man_flag) {
					  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nMantigora state ON."), HAL_MAX_DELAY);
					  //printf("Mantigora state ON.\r\n");
				  } else {
					  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nYou can on Mantigora."), HAL_MAX_DELAY);
					  //printf("You can on Mantigora.\r\n");
				  }

				  on_flag = 1;
			  }
		  }

		  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nADC value: %.3f%s%.3f%c", adc_value * adc_to_v, " 500: ", adc_value*adc_to_v*500, '@'), HAL_MAX_DELAY);


		  HAL_Delay(10);
		  HAL_GPIO_WritePin(UART_RS485_2_GPIO_Port, UART_RS485_2_Pin, GPIO_PIN_RESET);
	  }

	  if(tx_flag == 1 && HAL_GPIO_ReadPin(TX_SIGNAL_GPIO_Port, TX_SIGNAL_Pin) == 0) {
		  HAL_GPIO_WritePin(UART_RS485_2_GPIO_Port, UART_RS485_2_Pin, GPIO_PIN_SET);

		  //Прин�?ти�? значений дл�? прожига
		  if(((uint8_t) tx_buff[0]) - 48 > -1 && ((uint8_t) tx_buff[0]) - 48 < 10) {
			  heat_value = atoi((char*) tx_buff); //Перевод ASCII в int

		  	  if (heat_value == 0) {
		  		  HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, 0);
		  		  //HAL_GPIO_WritePin(NHEAT_GPIO_Port, NHEAT_Pin, GPIO_PIN_RESET);
		  		  HAL_GPIO_WritePin(HEAT_GPIO_Port, HEAT_Pin, GPIO_PIN_SET);

		  		  heat_flag = 1;
		  	  } else if (heat_value > 0 && heat_value % 100 == 0) {
		  		  heat_flag = 0;

		  		  HAL_GPIO_WritePin(HEAT_GPIO_Port, HEAT_Pin, GPIO_PIN_RESET);
		  		  //HAL_GPIO_WritePin(NHEAT_GPIO_Port, NHEAT_Pin, GPIO_PIN_SET);
		  		  HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, heat_value * 4095 / 1650); //Подача на Ц�?П напр�?жени�? 1:500 от нужного
		  		  heat_for_adc = heat_value;
		  	  } else {
		  		  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "Invalid heat voltage.@"), HAL_MAX_DELAY);
		  		  //printf("Invalid heat voltage.\r\n");
		  	  }

#ifdef TEST
		  	  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nData buffer: "), HAL_MAX_DELAY);
		  	  HAL_UART_Transmit(&huart5, tx_buff, strlen((char*) tx_buff), HAL_MAX_DELAY);
#endif

		  	  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nVoltage value: %d%c", (int) heat_value, '@'), HAL_MAX_DELAY);
		  	  //printf("Voltage value: %d%s", (int) heat_value, "\r\n");
		  	  //HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);

		  //Логика включени�? и выключени�? мантигоры. Пока on_flag = 1 �?то можно �?делать.
	  	  } else if (tx_buff[0] == 'O' && tx_buff[1] == 'N' && tx_buff[2] == '@' && on_flag == 1) {
	  		  HAL_GPIO_WritePin(ON_MAN_GPIO_Port, ON_MAN_Pin, GPIO_PIN_SET);
	  		  HAL_GPIO_WritePin(ON_MAN_LED_GPIO_Port, ON_MAN_LED_Pin, GPIO_PIN_SET);

	  		  on_man_flag = 1;

	  		  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nMantigore on.@"), HAL_MAX_DELAY);
	  		  //printf("Mantigore on.\r\n");
	  	  } else if (tx_buff[0] == 'O' && tx_buff[1] == 'F' && tx_buff[2] == 'F' && tx_buff[3] == '@') {
	  		  HAL_GPIO_WritePin(ON_MAN_GPIO_Port, ON_MAN_Pin, GPIO_PIN_RESET);
	  		  HAL_GPIO_WritePin(ON_MAN_LED_GPIO_Port, ON_MAN_LED_Pin, GPIO_PIN_RESET);

	  		  on_man_flag = 0;

	  		  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nMantigora off.@"), HAL_MAX_DELAY);
	  		  //printf("Mantigore off.\r\n");
	  	  } else if (tx_buff[0] == 'O' && tx_buff[1] == 'N' && tx_buff[2] == '@' && on_flag == 0) {
	  		  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nYou can't on Mantigora while ADC voltage is incorrect.@"), HAL_MAX_DELAY);
	  		  //printf("You can't on Mantigora while ADC voltage is incorrect.\r\n");
	  	  } else {
	  		  HAL_UART_Transmit(&huart5, msg, sprintf((char*) msg, "\nInvalid command.@"), HAL_MAX_DELAY);
	  		  //printf("Invalid command.\r\n");
	  	  }
		  HAL_GPIO_WritePin(UART_RS485_2_GPIO_Port, UART_RS485_2_Pin, GPIO_PIN_RESET);

		  memset(tx_buff, 0, strlen((char*) tx_buff));
		  tx_flag = 0;
	}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT2 config
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 115200;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, SCS_Pin|RST_Pin|ON_MAN_Pin|ON_MAN_LED_Pin
                          |RX_SIGNAL_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, HEAT_Pin|ON_ALLOW_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(UART_RS485_2_GPIO_Port, UART_RS485_2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : SCS_Pin RST_Pin ON_MAN_Pin ON_MAN_LED_Pin
                           RX_SIGNAL_Pin */
  GPIO_InitStruct.Pin = SCS_Pin|RST_Pin|ON_MAN_Pin|ON_MAN_LED_Pin
                          |RX_SIGNAL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : INT_Pin */
  GPIO_InitStruct.Pin = INT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(INT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : HEAT_Pin ON_ALLOW_Pin */
  GPIO_InitStruct.Pin = HEAT_Pin|ON_ALLOW_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : TX_SIGNAL_Pin */
  GPIO_InitStruct.Pin = TX_SIGNAL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(TX_SIGNAL_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : UART_RS485_2_Pin */
  GPIO_InitStruct.Pin = UART_RS485_2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(UART_RS485_2_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	//1 = TX, 0 = RX control pin - PG3 usr_name - UART_RS485
	if(rx_buff == '\r') { //конечный символ для принятия
		tx_buff[rx_count] = '@'; //конечный символ для отправки
		tx_size = rx_count; //кол-во переданных символов
		rx_count = 0; //сброс счётчика символов

		tx_flag = 1;
	} else {
		tx_buff[rx_count] = rx_buff; //запись данных из буффера
		++rx_count;
	}

	HAL_UART_Receive_IT(&huart5, &rx_buff, 1);
}

/*
int _write(int file, char *ptr, int len) {
	(void)file;
	if(file == 1){
		static uint8_t rc = USBD_OK;

		do {
			//USART_enable_UARTtx();
			rc = CDC_Transmit_FS((uint8_t*)ptr, len);
			//USART_enable_UARTrx();
		} while (USBD_BUSY == rc);

		if (USBD_FAIL == rc) {
			/// NOTE: Should never reach here.
			/// TODO: Handle this error.
			//HAL_GPIO_WritePin(ON_MAN_LED_GPIO_Port, ON_MAN_LED_Pin, GPIO_PIN_SET);
			return 0;
		}
	}

	//HAL_GPIO_WritePin(ON_MAN_LED_GPIO_Port, ON_MAN_LED_Pin, GPIO_PIN_RESET);
	return len;
}*/
/*
 void USB_RXCallback(uint8_t* Buf, uint32_t* Len){
	 //1 = TX, 0 = RX control pin - PG3 usr_name - UART_RS485
	 memcpy(tx_buff, Buf, *Len);
	 tx_buff[*Len-2] = '@'; //конечный символ для отправки
	 tx_size = *Len; //кол-во переданных символов

	 tx_flag = 1;
}
*/
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
