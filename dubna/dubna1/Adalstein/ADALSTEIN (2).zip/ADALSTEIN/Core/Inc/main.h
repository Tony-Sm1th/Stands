/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SCS_Pin GPIO_PIN_0
#define SCS_GPIO_Port GPIOC
#define RST_Pin GPIO_PIN_3
#define RST_GPIO_Port GPIOC
#define INT_Pin GPIO_PIN_0
#define INT_GPIO_Port GPIOA
#define HEAT_Pin GPIO_PIN_3
#define HEAT_GPIO_Port GPIOA
#define ON_MAN_Pin GPIO_PIN_4
#define ON_MAN_GPIO_Port GPIOC
#define ON_MAN_LED_Pin GPIO_PIN_6
#define ON_MAN_LED_GPIO_Port GPIOC
#define ON_ALLOW_Pin GPIO_PIN_8
#define ON_ALLOW_GPIO_Port GPIOA
#define TX_SIGNAL_Pin GPIO_PIN_10
#define TX_SIGNAL_GPIO_Port GPIOC
#define RX_SIGNAL_Pin GPIO_PIN_11
#define RX_SIGNAL_GPIO_Port GPIOC
#define UART_RS485_2_Pin GPIO_PIN_7
#define UART_RS485_2_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
